# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['starbelly_proto']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.3.1,<0.4.0',
 'protobuf>=3.12.2,<4.0.0',
 'trio-websocket>=0.8.0,<0.9.0',
 'trio>=0.15.1,<0.16.0']

entry_points = \
{'console_scripts': ['starbelly = starbelly_python_client.client:main']}

setup_kwargs = {
    'name': 'starbelly-python-client',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Luke',
    'author_email': 'Maxwell',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
