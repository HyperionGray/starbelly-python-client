def set_job(
    job_id: bytes = None,
    policy_id: bytes = None,
    seeds: list = None,
    name: str = None,
    tags: list = None,
):
    print(locals())
    for k, v in locals().items():
        print(k, v)


set_job()
